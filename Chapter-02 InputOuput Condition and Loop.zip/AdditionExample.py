a =int( input('enter data :'))
b = int(input('enter data :'))

c =a+b
print(c)
