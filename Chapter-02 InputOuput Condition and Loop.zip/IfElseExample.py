
#
amt = int(input('enter sales amt :'))

tax = 0
if amt>1000:
     tax = amt*.18 # amt*18/100
else:
     tax = amt*.05

     
total = amt+tax
print(total)

