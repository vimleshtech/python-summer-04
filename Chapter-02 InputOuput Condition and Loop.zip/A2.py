
rno = input('enter rno :')
name = input('enter name :')

hs =  int(input('enter mark in hindi :'))
es =int( input('enter mark in eng :'))
ms = int(input('enter mark in maths:'))
cs = int(input('enter mark in comp :'))
ss =int( input('enter mark in social :'))

total = hs+es+cs+ms+ss
avg = total/5

print(rno)
print(name)
print(total)
print(avg)
