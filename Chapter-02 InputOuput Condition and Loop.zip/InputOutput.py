# single line comment

#default input type is str 
a = input('etner data :')
b = input('enter data :')


#show data type
print(type(a))
print(type(b))

#convert str to int
a = int(a)
b = int(b)


print(type(a))
print(type(b))



c =a+b

print(c)
