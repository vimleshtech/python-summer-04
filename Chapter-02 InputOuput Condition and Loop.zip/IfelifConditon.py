
#
amt = int(input('enter sales amt :'))

tax = 0
if amt>100000:
     tax = amt*.28
elif amt>50000:
     tax = amt*.18
elif  amt>10000:
     tax = amt*.12
else:
     tax = amt*.05
     

     
total = amt+tax
print(total)


