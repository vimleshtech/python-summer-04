
a = input('enter data :')  #default input type is str 
b = input('enter data :')


print(type(a))
print(type(b))

#type conversion
a = int(a) #convert str to numebr /int
b = int(b)


print(type(a))
print(type(b))



o = a+b
print(o)


